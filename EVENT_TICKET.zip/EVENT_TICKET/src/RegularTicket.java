public class RegularTicket extends Ticket {
    public static final double PRICE = 20000;

    public RegularTicket(String id, String customerName, int quantity) throws InvalidTicketException {
        super(id, customerName, quantity);
    }

    public double getUnitPrice() { return PRICE; }
    public String getType() { return "Regular"; }
    public double calculateCharge() { return applyDiscount(grossCharge()); }
}
