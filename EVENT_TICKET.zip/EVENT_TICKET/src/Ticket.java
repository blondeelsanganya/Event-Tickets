public abstract class Ticket implements Chargeable {
    public static final double DISCOUNT_RATE = 0.08;
    public static final int DISCOUNT_MIN_TICKETS = 5;

    private String id;
    private String customerName;
    private int quantity;
    private boolean discountApplies;

    public Ticket(String id, String customerName, int quantity) throws InvalidTicketException {
        setId(id);
        setCustomerName(customerName);
        setQuantity(quantity);
    }

    public String getId() { return id; }
    public String getCustomerName() { return customerName; }
    public int getQuantity() { return quantity; }
    public boolean isDiscountApplied() { return discountApplies; }

    public void setId(String id) throws InvalidTicketException {
        if (id.trim().equals("")) throw new InvalidTicketException("ID must not be blank.");
        this.id = id.trim();
    }

    public void setCustomerName(String name) throws InvalidTicketException {
        if (name.trim().equals("")) throw new InvalidTicketException("Customer name must not be blank.");
        this.customerName = name.trim();
    }

    public void setQuantity(int quantity) throws InvalidTicketException {
        if (quantity <= 0) throw new InvalidTicketException("Quantity must be at least 1 (got " + quantity + ").");
        this.quantity = quantity;
        this.discountApplies = quantity >= DISCOUNT_MIN_TICKETS;
    }

    public abstract double getUnitPrice();
    public abstract String getType();
    public abstract double calculateCharge();

    protected double grossCharge() {
        return quantity * getUnitPrice();
    }

    protected double applyDiscount(double gross) {
        if (discountApplies) return gross * (1 - DISCOUNT_RATE);
        return gross;
    }

    public double getDiscountGiven() {
        return grossCharge() - calculateCharge();
    }

    public String toString() {
        String text = String.format("%-10s %-8s %-18s qty=%-3d charge=UGX %,.0f",
                id, getType(), customerName, quantity, calculateCharge());
        if (discountApplies) text = text + " (8% discount)";
        return text;
    }
}
