import java.util.List;

public class Main {
    static final String FULL_NAME = "SANGANYA MULENGEZI";
    static final String REG_NO = "VU-BSF-2511-0637-DAY";
    static final String ID_PREFIX = "SM637";

    public static void main(String[] args) {
        InputHelper input = new InputHelper();
        TicketManager mgr = new TicketManager(ID_PREFIX);

        System.out.println("=== Event Ticket Charging System ===");
        System.out.println("Name: " + FULL_NAME + "   Reg No: " + REG_NO);

        boolean running = true;
        while (running) {
            System.out.println("\n1. Add Regular ticket booking\n2. Add VIP ticket booking\n3. List report (highest charge first)"
                    + "\n4. Find booking\n5. Remove booking\n6. Summary\n7. Exit");
            int choice = input.readInt("Choose an option (1-7): ", 1, 7);
            try {
                if (choice == 1) addBooking(input, mgr, false);
                else if (choice == 2) addBooking(input, mgr, true);
                else if (choice == 3) report(mgr);
                else if (choice == 4) System.out.println(mgr.find(input.readText("Enter ID: ")));
                else if (choice == 5) removeBooking(input, mgr);
                else if (choice == 6) summary(mgr);
                else running = false;
            } catch (InvalidTicketException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        System.out.println("Goodbye.");
    }

    private static void addBooking(InputHelper input, TicketManager mgr, boolean vip) throws InvalidTicketException {
        String name = input.readText("Customer name: ");
        int qty = input.readInt("Number of tickets (1-1000): ", 1, 1000);
        String id = mgr.nextId();
        Ticket t;
        if (vip) t = new VipTicket(id, name, qty);
        else t = new RegularTicket(id, name, qty);
        mgr.add(t);
        System.out.println("Added: " + t);
    }

    private static void report(TicketManager mgr) {
        List<Ticket> list = mgr.sortedReport();
        if (list.size() == 0) {
            System.out.println("No bookings yet.");
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }

    private static void removeBooking(InputHelper input, TicketManager mgr) throws InvalidTicketException {
        Ticket t = mgr.find(input.readText("Enter ID to remove: "));
        System.out.println(t);
        if (input.readYesNo("Really remove this booking?")) {
            mgr.remove(t.getId());
            System.out.println("Removed.");
        } else {
            System.out.println("Cancelled.");
        }
    }

    private static void summary(TicketManager mgr) {
        System.out.println("Bookings: " + mgr.size());
        System.out.println("Total charges: UGX " + String.format("%,.0f", mgr.totalCharges()));
        System.out.println("Total discount given: UGX " + String.format("%,.0f", mgr.totalDiscount()));
    }
}
