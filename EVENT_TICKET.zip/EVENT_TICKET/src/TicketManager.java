import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TicketManager {
    private List<Ticket> tickets = new ArrayList<Ticket>();
    private String idPrefix;
    private int counter = 0;

    public TicketManager(String idPrefix) {
        this.idPrefix = idPrefix;
    }

    public String nextId() {
        counter++;
        return String.format("%s-%03d", idPrefix, counter);
    }

    public void add(Ticket t) {
        tickets.add(t);
    }

    public Ticket find(String id) throws InvalidTicketException {
        for (int i = 0; i < tickets.size(); i++) {
            if (tickets.get(i).getId().equalsIgnoreCase(id.trim())) return tickets.get(i);
        }
        throw new InvalidTicketException("No ticket found with ID " + id.trim() + ".");
    }

    public void remove(String id) throws InvalidTicketException {
        tickets.remove(find(id));
    }

    public double totalCharges() {
        double sum = 0;
        for (int i = 0; i < tickets.size(); i++) sum = sum + tickets.get(i).calculateCharge();
        return sum;
    }

    public double totalDiscount() {
        double sum = 0;
        for (int i = 0; i < tickets.size(); i++) sum = sum + tickets.get(i).getDiscountGiven();
        return sum;
    }

    public int size() {
        return tickets.size();
    }

    public List<Ticket> sortedReport() {
        List<Ticket> copy = new ArrayList<Ticket>(tickets);
        Collections.sort(copy, new Comparator<Ticket>() {
            public int compare(Ticket a, Ticket b) {
                return Double.compare(b.calculateCharge(), a.calculateCharge());
            }
        });
        return copy;
    }
}
