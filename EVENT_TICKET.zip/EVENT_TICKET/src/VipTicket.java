public class VipTicket extends Ticket {
    public static final double PRICE = 50000;

    public VipTicket(String id, String customerName, int quantity) throws InvalidTicketException {
        super(id, customerName, quantity);
    }

    public double getUnitPrice() { return PRICE; }
    public String getType() { return "VIP"; }
    public double calculateCharge() { return applyDiscount(grossCharge()); }
}
