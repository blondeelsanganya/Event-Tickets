import java.util.Scanner;

public class InputHelper {
    private Scanner in = new Scanner(System.in);

    private String line(String prompt) {
        System.out.print(prompt);
        if (!in.hasNextLine()) {
            System.out.println("\nInput closed. Goodbye.");
            System.exit(0);
        }
        return in.nextLine().trim();
    }

    public String readText(String prompt) {
        while (true) {
            String s = line(prompt);
            if (s.length() > 0) return s;
            System.out.println("  Input cannot be blank. Try again.");
        }
    }

    public int readInt(String prompt, int min, int max) {
        while (true) {
            String s = line(prompt);
            try {
                int v = Integer.parseInt(s);
                if (v >= min && v <= max) return v;
                System.out.println("  Enter a whole number from " + min + " to " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("  '" + s + "' is not a valid whole number. Try again.");
            }
        }
    }

    public boolean readYesNo(String prompt) {
        while (true) {
            String s = line(prompt + " (y/n): ").toLowerCase();
            if (s.equals("y") || s.equals("yes")) return true;
            if (s.equals("n") || s.equals("no")) return false;
            System.out.println("  Please answer y or n.");
        }
    }
}
